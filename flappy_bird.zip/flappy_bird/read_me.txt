# Flappy Bird Clone

This is a simple **Flappy Bird clone** built using **Python** and **Pygame**.

---

## Features
- Classic Flappy Bird gameplay.
- Score tracking with high score saved in `score.py`.
- Restart the game after collision by pressing **W**.
- Gradually increasing difficulty as the score increases.
- Customizable bird and pipe images.

---

## Requirements
- Python 3.x
- Pygame (`pip install pygame`)

---

## How to Run
run the flappy_bird.exe file in the flappy bird folder 